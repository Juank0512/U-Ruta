
""" Comentario: si se ubica este codigo en un archivo python .py
Debe importar los modulos seaborn y sklearn
Esto lo hace con:
pip install seaborn
pip install sklearn

Para que python intereactue con la base de datos MySQL, se requiere del paquete denominado mysqlclient
pip install mysqlclient

"""

#datos para la conexion a la base de datos
hostname = 'localhost'
username = 'root'
password = ''
database = 'labiii_p'

import MySQLdb
# inicialmente hace la conexion con la base de datos
myConnection = MySQLdb.connect( host=hostname, user=username, passwd=password, db=database )
import pandas as pd
import sys
var1= sys.argv[1]
var2= sys.argv[2]
var3= sys.argv[3]
var4= sys.argv[4]

# genera la lectura de la base de datos
dataframe_iris= pd.read_sql("SELECT * FROM iris_table",myConnection)
print("Va a imprimir el dataframe_iris leido de la BD...")
print(dataframe_iris)
# cierra la conexion con la base de datos
myConnection.close()


"""import seaborn as sns
iris = sns.load_dataset('iris')
iris
print(iris)"""

X = dataframe_iris[["sepal_length","sepal_width","petal_length","petal_width"]]
X.shape
y = dataframe_iris['species']
y.shape
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier()
from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, random_state=1, train_size=0.7)
model.fit(Xtrain, ytrain)
y_model = model.predict(Xtest)
from sklearn.metrics import accuracy_score
print("Accuracy:")
print(accuracy_score(ytest, y_model))
from sklearn.metrics import recall_score
print("Recall:")
print(recall_score(ytest, y_model, average='macro'))
from sklearn.metrics import precision_score
print("Precision:")
print(precision_score(ytest, y_model, average='macro'))

print("var1=")
print(var1)
print("var2=")
print(var2)
print("var3=")
print(var3)
print("var4=")
print(var4)

var1 = var1.replace("'", '')
var2 = var2.replace("'", '')
var3 = var3.replace("'", '')
var4 = var4.replace("'", '')


arreglo_var=[var1,var2,var3,var4]
print ("arreglo var es...")
print (arreglo_var)
y_model=model.predict([arreglo_var])
print("Especia predicha con los valores ingresados en el algoritmo:")
print(y_model)
respuesta_prediccion= format(y_model)
respuesta_prediccion = respuesta_prediccion.replace('[', '')
respuesta_prediccion = respuesta_prediccion.replace(']', '')
print("Prediccion:")
print(respuesta_prediccion)

mynewConnection = MySQLdb.connect( host=hostname, user=username, passwd=password, db=database )
cur = mynewConnection.cursor()
from datetime import datetime
now = datetime.now()
fecha = format(now.date()) 
hora = format(now.time())
cadena_SQL= "INSERT INTO predicciones (prediccion, fecha, hora) VALUES (" + respuesta_prediccion + ",'" + fecha + "','" + hora + "')"
print (cadena_SQL)
cur.execute(cadena_SQL)
print("Registro creado.")
# Si no se graba, no guarda el cambio de la creacion, guarda con commit
mynewConnection.commit()    
# Cierra la conexion
mynewConnection.close()




