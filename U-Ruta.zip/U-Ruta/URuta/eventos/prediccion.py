hostname = 'localhost'
username = 'root'
password = ''
database = 'zonadeparqueo'

import MySQLdb

myConnection = MySQLdb.connect( host=hostname, user=username, passwd=password, db=database )
import pandas as pd

dataframe_registros= pd.read_sql("SELECT zona,puesto,hora, ingreso FROM tablaml",myConnection)
print("Va a imprimir el dataframe_registros leido de la BD...")
print(dataframe_registros)

myConnection.close()


X = dataframe_registros[["zona","puesto","hora"]]
X.shape
y = dataframe_registros['ingreso']
y.shape
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier()
from sklearn.model_selection import train_test_split
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, random_state=1, train_size=0.7)
model.fit(Xtrain, ytrain)
y_model = model.predict(Xtest)
from sklearn.metrics import accuracy_score
print("Accuracy:")
print(accuracy_score(ytest, y_model))
from sklearn.metrics import recall_score
print("Recall:")
print(recall_score(ytest, y_model, average='macro'))
from sklearn.metrics import precision_score
print("Precision:")
print(precision_score(ytest, y_model, average='macro'))

prediccionC = MySQLdb.connect( host=hostname, user=username, passwd=password, db=database )
#import pandas as pd

dataframe_pre= pd.read_sql("SELECT zona,puesto,hora FROM consultaprediccion WHERE id=0",prediccionC)
print("Va a imprimir el dataframe_registros leido de la BD...")
print(dataframe_pre)
prediccionC.close()


y_model=model.predict(dataframe_pre[["zona","puesto","hora"]])
print("Especia predicha con los valores ingresados en el algoritmo:")
print(y_model)
respuesta_prediccion= format(y_model)
respuesta_prediccion = respuesta_prediccion.replace('[', '')
respuesta_prediccion = respuesta_prediccion.replace(']', '')
print("Prediccion:")
print(respuesta_prediccion)

mynewConnection = MySQLdb.connect( host=hostname, user=username, passwd=password, db=database )
cur = mynewConnection.cursor()
from datetime import datetime
now = datetime.now()
fecha = format(now.date()) 
hora = format(now.time())
horaR = hora[0:8]
res = respuesta_prediccion.replace(".", "")

cadena_SQL= "UPDATE prediccion set prediccion=" + res + ", fecha='" + fecha + "'" + ", hora='" + horaR + "'" + " where id=0"
print (cadena_SQL)
cur.execute(cadena_SQL)
print("Registro creado.")
# Si no se graba, no guarda el cambio de la creacion, guarda con commit
mynewConnection.commit()    
# Cierra la conexion
mynewConnection.close()




