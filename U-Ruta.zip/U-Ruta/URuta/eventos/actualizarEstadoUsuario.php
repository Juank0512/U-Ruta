<?php
	include "conexion.php";

	$idUsuario = $_POST["idUsuario"];
	$estado = $_POST["estado"];

	$mysqli = new mysqli($host, $user, $pw, $db); 

	$sqlActualizar = "UPDATE usuarios set estado = '$estado' WHERE idUsuario = '$idUsuario'"; 

	$resActualizar = $mysqli->query($sqlActualizar);

?>