<?php
	include "conexion.php";

	//$estadoPago = $_POST["estadoPago"];
	$idUsuario = $_POST["idUsuario"];

	$mysqli = new mysqli($host, $user, $pw, $db); 

	date_default_timezone_set('America/Bogota');
	$fecha =  date("Y-m-d");
	$hora = date("H:i:s");

	$sqlActualizar = "UPDATE registrosTarifas set estadoPago = 1, fechaPago='$fecha', horaPago='$hora' where idUsuario = '$idUsuario' and estadoPago = 0"; 

	$resActualizar = $mysqli->query($sqlActualizar);
	echo "".$resActualizar;
?>
