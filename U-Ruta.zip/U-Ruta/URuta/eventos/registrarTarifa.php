<?php
  include "../eventos/conexion.php";
  
  $idUsuario = $_POST['idUsuario'];
  $zona = $_POST['zona'];
  $puesto = $_POST['puesto'];

  $mysqli = new mysqli($host, $user, $pw, $db); 

  $sqlHora = "SELECT hora, fecha FROM registros WHERE idUsuario='$idUsuario' and idTipoDeAccion= 2 order by idRegistro DESC LIMIT 1"; 

  $resHora = $mysqli->query($sqlHora);
  //echo "resp".$resHora;

  $rowH = $resHora->fetch_array(MYSQLI_NUM);
  $horaOcupacion = $rowH[0];
  $fechaOcupacion = $rowH[1];

  date_default_timezone_set('America/Bogota');
  $horaActual = date("H:i:s");
  $fechaActual =  date("Y-m-d");

  $final = date_create($horaOcupacion);
  $inicio = date_create($horaActual);
  $diferen = date_diff($inicio, $final);

  $tiempo = $diferen-> days * 24 * 60;
  $tiempo += $diferen-> h * 60;
  $tiempo += $diferen-> i;
  $minutos = $tiempo;
  $tiempo += $diferen-> s;
  $segundos = $tiempo;

  $sqlTarifa = "SELECT tarifaInicial, porcentajeTarifaAdicional from tarifas"; 
  $resTarifa = $mysqli->query($sqlTarifa);
  $rowTarifa = $resTarifa->fetch_array(MYSQLI_NUM);
  $tarifa = $rowTarifa[0];
  $porcentajeTarifaAdicional = $rowTarifa[1];
  $tarifaAdicional = $porcentajeTarifaAdicional;



  if($minutos==0 && $minutos < 140){
    $tarifaF = $tarifa;
  }else if($minutos>=140){
    $tarifaF =$porcentajeTarifaAdicional;
  }

  $sqlRegistro = "INSERT into registrostarifas (idUsuario, tarifa, fechaOcupacion, horaOcupacion, zona, puesto, tarifaAdicional, fechaTerminacion, horaTerminacion, estadoPago, fechaPago, horaPago) VALUES ('$idUsuario', '$tarifaF', '$fechaOcupacion', '$horaOcupacion', '$zona', '$puesto', 0 , '$fechaActual', '$horaActual',0,'$fechaActual', '$horaActual')"; 

  $resRegistro = $mysqli->query($sqlRegistro); 
?>
