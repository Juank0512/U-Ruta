<?php
//echo "Se va a ejecutar el script de python de predicci&oacute;n<br><br>";
echo shell_exec("prediccion.py");

?>