<?php
  include "../eventos/conexion.php";  
  $mysqli = new mysqli($host, $user, $pw, $db); 
  session_start();
  if ($_SESSION["autenticado"] != "SIx5"){
    header('Location: index.php');
  }
  $idUsuario = $_SESSION['idUsuario'];
  $usuario = $_SESSION['usuario'];

  if (isset($_GET['idUsuarioM'])) {
    $idUsuarioM = $_GET['idUsuarioM'];
  }else{
    $idUsuarioM = $_POST['idUsuarioM'];
  }
  
  $sqlEU= "SELECT estado FROM usuarios where idUsuario='$idUsuario'"; 
  $resEU = $mysqli->query($sqlEU);
  $rowEU = $resEU->fetch_array(MYSQLI_NUM);

  $estadoUsuario = $rowEU[0];

  if($estadoUsuario==0){
    unset($_SESSION["usuario"]); 
    unset($_SESSION["autenticado"]);
    session_destroy();
    header('Location: /zonaDeParqueo/index.php');
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title>Zona De Parqueo</title>
      <meta charset="utf-8">
      <meta http-equiv="refresh" content="400"/>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
      <script src="/zonaDeParqueo/js/vtnVisualizarPuestos.js"></script>
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/menu.css">
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/btnVisualizarPuestos.css">
    </head>
    <body>
      <ul class="menu">
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInicio.php">Inicio</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php">Gestión Usuarios</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInformes.php">Informes</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminEstadisticas.php">Estadísticas</a></li>
        <li><a href="#">Acerca De</a></li>
        <li class="item_sesion"><a href="/zonaDeParqueo/eventos/cerrarSesion.php">Cerrar Sesión</a></li>
        <li class="item_sesion"><a href="#"><?php echo $usuario;?></a>
        </li>
      </ul>
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="FFFFFF" class="tabla">
        <tr>
          <td valign="top" align=center width=80 colspan=1 class="tdima">
            <img src="/zonaDeParqueo/img/SmartParking.jpg" width=1210 height=250>
          </td>
        </tr>
        <tr>
          <td valign="top" align=center width=80 height=10 colspan=1 class="tdima">
            <h1> <font color=white>Modificar Usuario</font></h1>
          </td>
        </tr>
        <tr>
          <?php
            $sql1 = "SELECT * FROM usuarios inner join tiposusuario on usuarios.idTipoUsuario=tiposusuario.idTipoUsuario WHERE idUsuario='$idUsuarioM'";
            $result1 = $mysqli->query($sql1);
            $row1 = $result1->fetch_array(MYSQLI_NUM);

            $usuario = $row1[1];
            $con = $row1[2];
            $nombres = $row1[3];
            $apellidos = $row1[4];
            $idTipoUsuario = $row1[6];
            $contrasena = md5($con);
          ?>
          <td align="center">
            <form id="formRegistro" class="form" action="/zonaDeParqueo/vtn/vtnAdminModificarUsuario.php" method="POST">
              <font>Usuario</font>
              <input type="hidden" name="idUsuarioM" id="idUsuarioM" value="<?php echo "".$idUsuarioM?>">
              <input type="text" name="nombreUsuario" id="nombreUsuario" value="<?php echo "".$usuario?>">
              <font>Nombres</font>
              <input type="text" name="nombre" id="nombre" value="<?php echo "".$nombres?>">
              <font>Apellidos</font>
              <input type="text" name="apellido" id="apellido" value="<?php echo "".$apellidos?>">
              <font>Contraseña</font>
              <input type="password" name="contrasena" id="contrasena">
              <font>Tipo Usuario</font>
              <select name="tipoUsuario" id="tipoUsuario">
                <option value="1">Administrador</option>
                <option value="2">Consultor</option>
              </select> 
              <input type="submit" value="Actualizar" name="actualizar" class="btnA">
              <input type="submit" value="Eliminar" name="eliminar" class="btnE">
            </form>
            <a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php"><button class="btnC">Cancelar</button></a> 
          </td>
        </tr>
        <?php 
          if (isset($_POST['actualizar'])) {
            $usuarioM = $_POST['nombreUsuario'];
            $nombresM = $_POST['nombre'];
            $apellidosM = $_POST['apellido'];
            $idTipoUsuarioM = $_POST['tipoUsuario'];
            $contrasenaM = $_POST['contrasena'];
            $contra = md5($contrasenaM);
            /*echo "".$usuarioM;
            echo " ".$nombresM;
            echo " ".$apellidosM;
            echo " ".$idTipoUsuarioM;
            echo " ".$contra;*/

            $sqlUD = "UPDATE usuarios SET usuario=";
            $sqlUD = $sqlUD.'"'.$usuarioM.'", '.'contrasenia='.'"'.$contra.'", '.'nombres='.'"'.$nombresM.'", '.'apellidos='.'"'.$apellidosM.'", '.'idTipoUsuario='.$idTipoUsuarioM.' WHERE idUsuario='.$idUsuarioM;
            $resUD = $mysqli->query($sqlUD);

            echo "<script type='text/javascript'>
                    Swal.fire({
                          title: 'Usuario Actualizado',
                          icon: 'success',
                          backdrop: true,
                          text: 'Se ha modificado la información del usuario exitosamente',
                          timer: 10000
                        }).then((result) => {
                          location.href='/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php';
                        })
                  </script>";
          }

          if (isset($_POST['eliminar'])) {
            $sqlE = "DELETE  FROM usuarios WHERE idUsuario='$idUsuarioM'";
            $resE = $mysqli->query($sqlE);

            echo "<script type='text/javascript'>
                    Swal.fire({
                          title: 'Usuario Eliminado',
                          icon: 'success',
                          backdrop: true,
                          text: 'Se ha eliminado el usuario',
                          timer: 10000
                        }).then((result) => {
                          location.href='/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php';
                        })
                  </script>";
          }
        ?>
    </body>
    <style type="text/css">
      .btnA{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnA{
        border: none;
        outline: none;
        height: 25px;
        background: #1A6CBB;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnA:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

      .btnE{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnE{
        border: none;
        outline: none;
        height: 25px;
        background: #C72A39;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnE:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

      .btnC{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnC{
        border: none;
        outline: none;
        height: 25px;
        background: #CA3967;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnC:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }
    </style>
    </table>
  </html>