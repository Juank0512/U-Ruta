<?php
  include "../eventos/conexion.php";  
  $mysqli = new mysqli($host, $user, $pw, $db); 
  session_start();
  if ($_SESSION["autenticado"] != "SIx5"){
    header('Location: index.php');
  }
  $idUsuario = $_SESSION['idUsuario'];
  $usuario = $_SESSION['usuario'];
  
  $sqlEU= "SELECT estado FROM usuarios where idUsuario='$idUsuario'"; 
  $resEU = $mysqli->query($sqlEU);
  $rowEU = $resEU->fetch_array(MYSQLI_NUM);

  $estadoUsuario = $rowEU[0];

  if($estadoUsuario==0){
    unset($_SESSION["usuario"]); 
    unset($_SESSION["autenticado"]);
    session_destroy();
    header('Location: /zonaDeParqueo/index.php');
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title>Zona De Parqueo</title>
      <meta charset="utf-8">
      <meta http-equiv="refresh" content="400"/>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
      <script src="/zonaDeParqueo/js/vtnVisualizarPuestos.js"></script>
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/menu.css">
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/btnVisualizarPuestos.css">
    </head>
    <body>
      <ul class="menu">
          <li><a href="/zonaDeParqueo/vtn/vtnAdminInicio.php">Inicio</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php">Gestión Usuarios</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInformes.php">Informes</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminEstadisticas.php">Estadísticas</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminHistorialPuestos.php">Historial Puestos</a></li>
        <li><a href="#">Acerca De</a></li>
        <li class="item_sesion"><a href="/zonaDeParqueo/eventos/cerrarSesion.php">Cerrar Sesión</a></li>
        <li class="item_sesion"><a href="#"><?php echo $usuario;?></a>
        </li>
      </ul>
      <table width="80%" align=center cellpadding=6 border=1 bgcolor="FFFFFF" class="tabla">
        <tr>
          <td valign="top" align=center width=80 colspan=6 class="tdima">
            <img src="/zonaDeParqueo/img/SmartParking.jpg" width=1210 height=250>
          </td>
        </tr>
        <tr class="submenu">
          <td valign="top" align=center width=80 height=20 colspan=3 bgcolor="#001532">
              <a href="/zonaDeParqueo/vtn/vtnAdminInformesIngresos.php">Ingresos</a>
          </td>
          <td valign="top" align=center width=80 height=20 colspan=3 bgcolor="#001532">
              <a href="/zonaDeParqueo/vtn/vtnAdminInformes.php">Ingresos Totales</a>
          </td>
        </tr>
        <tr class="submenu">
          <form action="/zonaDeParqueo/vtn/vtnAdminInformes.php" method="POST">
            <td valign="top" align=center width=80 height=20 colspan=6 bgcolor="#001532">
              <font color="white">Ingrese nombre de usuario: </font>
              <input type="text" name="nombre" id="nombre">
              <input type="submit" value="Enviar" name="enviar" class="btnE">
            </td>
          </form>
        </tr>
        <tr>
          <td valign="top" align=center bgcolor="44709B">
            <b>#</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Usuario</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Total Tarifas Pagado</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Total Tarifas Adicionales Pagado</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Total Pagado</b>
          </td>
        </tr>
      <?php
        if (isset($_POST['enviar'])) {
          $nombre = $_POST['nombre'];

          $sql1 = "SELECT idUsuario FROM usuarios WHERE idTipoUsuario=2 and nombres LIKE ";
          $sql1 = $sql1.'"'.'%'.$nombre.'%'.'" '.'order by idUsuario LIMIT 10';

        }else{
          $sql1 = "SELECT idUsuario FROM usuarios WHERE idTipoUsuario=2 order by idUsuario LIMIT 10";
        }
        

        $result1 = $mysqli->query($sql1);
        $contador = 0;

        while($row1 = $result1->fetch_array(MYSQLI_NUM)){
          $idUsuarioC = $row1[0];

          $sqlSumTarifa = "SELECT tarifa FROM registrostarifas where idUsuario='$idUsuarioC'"; 
          $resSumTarifa = $mysqli->query($sqlSumTarifa);
          $numFilasSumTarifa = $resSumTarifa->num_rows;

          if($numFilasSumTarifa>0){
            $rowSumTarifa = $resSumTarifa->fetch_array(MYSQLI_NUM);
            $tarifaC = $rowSumTarifa[0];
          }else{
            $tarifaC=0;
            
          }

          $sqlSumTarifaA = "SELECT SUM(tarifaAdicional) as sumTarifaA FROM registrostarifas where idUsuario='$idUsuarioC'"; 

          $resSumTarifaA = $mysqli->query($sqlSumTarifaA);
          $numFilasSumTarifaA = $resSumTarifaA->num_rows;
          if($numFilasSumTarifaA>0){
            $rowSumTarifaA = $resSumTarifaA->fetch_array(MYSQLI_NUM);
            $tarifaA = $rowSumTarifaA[0];
          }else{
            $tarifaA=0;
          }
          $tarifa = $tarifaC + $tarifaA;

          $sqlUsu = "SELECT nombres FROM usuarios where idUsuario = '$idUsuarioC'"; 
          $resultU = $mysqli->query($sqlUsu);
          $rowU = $resultU->fetch_array(MYSQLI_NUM);
          $UsuarioC = $rowU[0];

          $contador++;

      ?>
      <tr>
        <td valign="middle" align=center>
          <?php echo $contador; ?> 
        </td>
        <td valign="middle" align=center>
          <?php echo $UsuarioC; ?> 
        </td>
        <td valign="middle" align=center>
          <?php echo $tarifaC; ?> 
        </td> 
        <td valign="middle" align=center>
          <?php echo $tarifaA; ?> 
        </td> 
        <td valign="middle" align=center>
          <?php echo $tarifa; ?> 
        </td> 
        <?php
          }
        ?>
      </tr>
      <style type="text/css">
        .submenu td a{
          text-decoration: none;
          color: white;
          padding: 20px;
          display: block;
        }
        .submenu td a:hover{
          background: #11C6C4;
        }

      .btnE{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnE{
        border: none;
        outline: none;
        height: 25px;
        background: #5DF96B;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnE:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }
      </style>
    </body>
    </table>
  </html>