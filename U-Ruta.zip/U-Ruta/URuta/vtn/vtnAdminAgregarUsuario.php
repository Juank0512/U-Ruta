<?php
  include "../eventos/conexion.php";  
  $mysqli = new mysqli($host, $user, $pw, $db); 
  session_start();
  if ($_SESSION["autenticado"] != "SIx5"){
    header('Location: index.php');
  }
  $idUsuario = $_SESSION['idUsuario'];
  $usuario = $_SESSION['usuario'];
  
  $sqlEU= "SELECT estado FROM usuarios where idUsuario='$idUsuario'"; 
  $resEU = $mysqli->query($sqlEU);
  $rowEU = $resEU->fetch_array(MYSQLI_NUM);

  $estadoUsuario = $rowEU[0];

  if($estadoUsuario==0){
    unset($_SESSION["usuario"]); 
    unset($_SESSION["autenticado"]);
    session_destroy();
    header('Location: /zonaDeParqueo/index.php');
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title>Zona De Parqueo</title>
      <meta charset="utf-8">
      <meta http-equiv="refresh" content="400"/>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
      <script src="/zonaDeParqueo/js/vtnVisualizarPuestos.js"></script>
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/menu.css">
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/btnVisualizarPuestos.css">
    </head>
    <body>
      <ul class="menu">
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInicio.php">Inicio</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php">Gestión Usuarios</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInformes.php">Informes</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminEstadisticas.php">Estadísticas</a></li>
        <li><a href="#">Acerca De</a></li>
        <li class="item_sesion"><a href="/zonaDeParqueo/eventos/cerrarSesion.php">Cerrar Sesión</a></li>
        <li class="item_sesion"><a href="#"><?php echo $usuario;?></a>
        </li>
      </ul>
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="FFFFFF" class="tabla">
        <tr>
          <td valign="top" align=center width=80 colspan=1 class="tdima">
            <img src="/zonaDeParqueo/img/SmartParking.jpg" width=1210 height=250>
          </td>
        </tr>
        <tr>
          <td valign="top" align=center width=80 height=10 colspan=1 class="tdima">
            <h1> <font color=white>Registrar Usuario</font></h1>
          </td>
        </tr>
        <tr>
          <td align="center">
            <form id="formRegistro" class="form" action="/zonaDeParqueo/vtn/vtnAdminAgregarUsuario.php" method="POST">
              <font>Usuario</font>
              <input type="text" name="nombreUsuario" id="nombreUsuario" placeholder="Nombre Usuario">
              <font>Nombres</font>
              <input type="text" name="nombre" id="nombre" placeholder="Nombres">
              <font>Apellidos</font>
              <input type="text" name="apellido" id="apellido" placeholder="Apellidos">
              <font>Contraseña</font>
              <input type="password" name="contrasena" id="contrasena" placeholder="Contraseña">
              <font>Tipo Usuario</font>
              <select name="tipoUsuario" id="tipoUsuario">
                <option value="1">Administrador</option>
                <option value="2">Consultor</option>
              </select> 
              <input type="submit" value="Agregar" name="agregar" class="btnA">
            </form>
            <a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php"><button class="btnC">Cancelar</button></a> 
          </td>
        </tr>
        <?php 
          if (isset($_POST['agregar'])) {
            $usuarioM = $_POST['nombreUsuario'];
            $nombresM = $_POST['nombre'];
            $apellidosM = $_POST['apellido'];
            $idTipoUsuarioM = $_POST['tipoUsuario'];
            $contrasenaM = $_POST['contrasena'];
            $contra = md5($contrasenaM);
            if(strlen($usuarioM)>0 or strlen($nombresM)>0 or strlen($apellidosM)>0){
              $sqlLogueo = "SELECT * FROM usuarios where usuario='$usuarioM'";
              $resLogueo = $mysqli->query($sqlLogueo);
              $numFilas = $resLogueo->num_rows;

              if($numFilas>0){
                echo "<script type='text/javascript'>
                      Swal.fire({
                            title: 'Usuario Existente',
                            icon: 'warning',
                            backdrop: true,
                            text: 'El nombre de usuario ingresado ya existe',
                            timer: 10000
                          })
                    </script>";
              }else{
                $sqlRegistro = "INSERT INTO usuarios(usuario, contrasenia, nombres, apellidos, idTipoUsuario,estado) values('$usuarioM', '$contra', '$nombresM', '$apellidosM', '$idTipoUsuarioM',1)";
                $resRegistro = $mysqli->query($sqlRegistro);

                if($resRegistro==1){
                  echo "<script type='text/javascript'>
                      Swal.fire({
                            title: 'Usuario Registrado',
                            icon: 'success',
                            backdrop: true,
                            text: 'Se ha registrado el usuario exitosamente',
                            timer: 10000
                          }).then((result) => {
                            location.href='/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php';
                          })
                    </script>";
                }
              }
            }else{
              echo "<script> Swal.fire('Campo Obligatorio', 'Debe llenar todos los campos', 'error')</script>";
            }
          }
        ?>
    </body>
    <style type="text/css">
      .btnA{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnA{
        border: none;
        outline: none;
        height: 25px;
        background: #5DF96B;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnA:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

      .btnC{
        width: 10%;
        margin-bottom: 0px;
      }
      .btnC{
        border: none;
        outline: none;
        height: 25px;
        background: #CA3967;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnC:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }
    </style>
    </table>
  </html>