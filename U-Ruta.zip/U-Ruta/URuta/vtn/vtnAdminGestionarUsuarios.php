<?php
  include "../eventos/conexion.php";  
  $mysqli = new mysqli($host, $user, $pw, $db); 
  session_start();
  if ($_SESSION["autenticado"] != "SIx5"){
    header('Location: index.php');
  }
  $idUsuario = $_SESSION['idUsuario'];
  $usuario = $_SESSION['usuario'];

  $sqlEU= "SELECT estado FROM usuarios where idUsuario='$idUsuario'"; 
  $resEU = $mysqli->query($sqlEU);
  $rowEU = $resEU->fetch_array(MYSQLI_NUM);

  $estadoUsuario = $rowEU[0];

  if($estadoUsuario==0){
    unset($_SESSION["usuario"]); 
    unset($_SESSION["autenticado"]);
    session_destroy();
    header('Location: /zonaDeParqueo/index.php');
  }
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title>Zona De Parqueo</title>
      <meta charset="utf-8">
      <meta http-equiv="refresh" content="400"/>
      <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>
      <script src="/zonaDeParqueo/js/vtnVisualizarPuestos.js"></script>
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/menu.css">
      <link rel="stylesheet" type="text/css" href="/zonaDeParqueo/css/btnVisualizarPuestos.css">
    </head>
    <body>
      <ul class="menu">
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInicio.php">Inicio</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php">Gestión Usuarios</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminInformes.php">Informes</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminEstadisticas.php">Estadísticas</a></li>
        <li><a href="/zonaDeParqueo/vtn/vtnAdminHistorialPuestos.php">Historial Puestos</a></li>
        <li><a href="#">Acerca De</a></li>
        <li class="item_sesion"><a href="/zonaDeParqueo/eventos/cerrarSesion.php">Cerrar Sesión</a></li>
        <li class="item_sesion"><a href="#"><?php echo $usuario;?></a>
        </li>
      </ul>
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="FFFFFF" class="tabla">
        <tr>
          <td valign="top" align=center width=80 colspan=6 class="tdima">
            <img src="/zonaDeParqueo/img/SmartParking.jpg" width=1210 height=250>
          </td>
        </tr>
        <tr>
          <td valign="top" align=center width=80 height=10 colspan=6 class="tdima">
            <h1> <font color=white>Usuarios registrados</font></h1>
             <a href="/zonaDeParqueo/vtn/vtnAdminAgregarUsuario.php"><button class="btnA">Agregar Usuario</button></a>
          </td>
        </tr>
        <tr class="submenu">
          <form action="/zonaDeParqueo/vtn/vtnAdminGestionarUsuarios.php" method="POST" class="cons">
            <td valign="top" align=center width=80 height=20 colspan=6 bgcolor="#001532">
              <font color="white">Ingrese nombre de usuario o apellido: </font>
              <input type="text" name="nombre" id="nombre">
              <input type="submit" value="Enviar" name="enviar" class="enviar">
          </form>
        </tr>
        <tr>
          <td valign="top" align=center bgcolor="44709B">
            <b>#</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Usuario</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Nombres</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Apellidos</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Tipo Usuario</b>
          </td>
          <td valign="top" align=center bgcolor="44709B">
            <b>Opción</b>
          </td>
        </tr>
      <?php
        if (isset($_POST['enviar'])) {
          $nombre = $_POST['nombre'];
          if(empty($nombre)){
            echo "<script> Swal.fire('Campo Vacio', 'Debe llenar el campo para continuar con la busqueda', 'error')</script>";
            $sql1 = "SELECT * FROM usuarios WHERE idUsuario!=0";
          }else{
            $sql1 = "SELECT * FROM usuarios WHERE idUsuario!=0 AND nombres LIKE ";
            $sql1 = $sql1.'"'.'%'.$nombre.'%'.'"'.' or apellidos LIKE '.'"'.'%'.$nombre.'%'.'"';
          }
        }else{
          $sql1 = "SELECT * FROM usuarios WHERE idUsuario!=0";
        }

        $result1 = $mysqli->query($sql1);
        $contador = 0;

        while($row1 = $result1->fetch_array(MYSQLI_NUM)){
          $idUsuarioM  = $row1[0];
          $usuario = $row1[1];
          $nombres = $row1[3];
          $apellidos = $row1[4];
          $idTipoUsuario = $row1[5];

          $contador++;

      ?>
      <tr>
        <td valign="middle" align=center>
          <?php echo $contador; ?> 
        </td>
        <td valign="middle" align=center>
          <?php echo $usuario; ?> 
        </td>
        <td valign="middle" align=center>
          <?php echo $nombres; ?> 
        </td> 
        <td valign="middle" align=center>
          <?php echo $apellidos; ?> 
        </td> 
        <td valign="middle" align=center>
          <?php echo $idTipoUsuario; ?> 
        </td> 
        <td valign="middle" align=center>
          <a href="/zonaDeParqueo/vtn/vtnAdminModificarUsuario.php?idUsuarioM=<?php echo $idUsuarioM; ?> "><button class="btn">Gestionar</button></a>
        </td> 
        <?php
          }
        ?>
      </tr>
    </body>
    <style type="text/css">
      .btn{
        width: 50%;
        margin-bottom: 0px;
      }
      .btn{
        border: none;
        outline: none;
        height: 25px;
        background: #1554C8;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btn:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

      .btnA{
        width: 20%;
        margin-bottom: 0px;
      }
      .btnA{
        border: none;
        outline: none;
        height: 25px;
        background: #5DF96B;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .btnA:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

      .enviar{
        width: 10%;
        margin-bottom: 0px;
      }
      .enviar{
        border: none;
        outline: none;
        height: 25px;
        background: #5DF96B;
        color: #000;
        font-size: 18px;
        border-radius: 20px;
      }

      .enviar:hover {
        cursor: pointer;
        background: #ffc107;
        color: #000;
      }

    </style>
    </table>
  </html>